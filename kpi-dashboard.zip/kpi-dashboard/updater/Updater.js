// updater/updater.js
// Run with: node updater/updater.js

console.log(`
📋 MANUAL UPDATE INSTRUCTIONS:

To update dashboard data:

1. 📊 MAIN KPI DATA
   - Open Excel → 'Date' sheet
   - Copy all data (Ctrl+A, Ctrl+C)
   - Paste to: data/main-data.txt

2. 📦 OTD FACTORS
   - Open Excel → 'OTD' sheet
   - Copy all data
   - Paste to: data/otd.txt

3. ⚙️ OEE FACTORS
   - Open Excel → 'OEE' sheet
   - Copy all data
   - Paste to: data/oee.txt

4. 🧵 YMR FACTORS
   - Open Excel → 'YMR' sheet
   - Copy all data
   - Paste to: data/ymr.txt

5. Commit and push to GitHub
   git add data/
   git commit -m "Update dashboard data"
   git push

✅ Vercel will auto-deploy!
`);